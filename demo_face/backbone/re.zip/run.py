# -*- coding:utf-8 -*-
import cv2
import sys
import time
import numpy as np
# import gc
import multiprocessing as mp
from argparse import ArgumentParser

from retinaface import Retinaface
# from settings import camera_data, img_shape
from settings import cam_addrs, img_shape


# 捕获视频流
def push_image(raw_q, cam_addr):
    cap = cv2.VideoCapture(cam_addr, cv2.CAP_FFMPEG)
    # cap = cv2.VideoCapture(cam_addr)
    while True:
        is_opened, frame = cap.read()
        t1 = time.time()
        if is_opened:
            raw_q.put((frame, cam_addr, t1))
        else:
            cap = cv2.VideoCapture(cam_addr, cv2.CAP_FFMPEG)
            # cap = cv2.VideoCapture(cam_addr)
        if raw_q.qsize() > 5:
            # 删除旧图片
            raw_q.get()
        else:
            # 等待
            time.sleep(0.1)


# 将原始队列中图像进行预测后放入预测队列
def predict(raw_q, pred_q):
    retinaface = Retinaface()

    while True:
        # t1 = time.time()
        # 读取某一帧
        raw_img, cam_address, t1 = raw_q.get()

        # 格式转变，BGRtoRGB
        raw_img = cv2.cvtColor(raw_img, cv2.COLOR_BGR2RGB)
        # 进行检测
        pred_img = np.array(retinaface.detect_image(raw_img, 'output/result', t1, cam_address))
        # RGBtoBGR满足opencv显示格式
        pred_img = cv2.cvtColor(pred_img, cv2.COLOR_RGB2BGR)
        pred_q.put(pred_img)
        toc = time.time()
        time_cost = toc - t1
        print('Processed in %.3fs FPS = %.3f' % (time_cost, 1 / time_cost))


# 取出预测队列中的图像
def pop_image(pred_q, window_name, img_shape):
    cv2.namedWindow(window_name, flags=cv2.WINDOW_FREERATIO)
    while True:
        frame = pred_q.get()
        frame = cv2.resize(frame, img_shape)
        cv2.imshow(window_name, frame)
        cv2.waitKey(1)


# 显示
def display(cam_addrs, window_names, img_shape=(300, 300)):
    raw_queues = [mp.Queue(maxsize=2) for _ in cam_addrs]
    pred_queues = [mp.Queue(maxsize=4) for _ in cam_addrs]
    processes = []

    for raw_q, pred_q, cam_addr, window_name in zip(raw_queues, pred_queues, cam_addrs, window_names):
        processes.append(mp.Process(target=push_image, args=(raw_q, cam_addr)))
        processes.append(mp.Process(target=predict, args=(raw_q, pred_q)))
        processes.append(mp.Process(target=pop_image, args=(pred_q, window_name, img_shape)))

    [setattr(process, "daemon", True) for process in processes]
    [process.start() for process in processes]
    [process.join() for process in processes]


def combine_images(queue_list, window_name, img_shape):
    cv2.namedWindow(window_name, flags=cv2.WINDOW_FREERATIO)
    num_cameras = len(queue_list)

    while True:
        imgs = [cv2.resize(q.get(), img_shape) for q in queue_list]
        x = np.concatenate(imgs[:num_cameras // 2], axis=1)
        y = np.concatenate(imgs[-(num_cameras - num_cameras // 2):], axis=1)
        imgs = np.concatenate([x, y], axis=0)
        cv2.imshow(window_name, imgs)
        cv2.waitKey(1)


# 单窗口显示，需要摄像头分辨率相同
def display_single_window(cam_addrs, window_name='camera', img_shape=(300, 300)):
    raw_queues = [mp.Queue(maxsize=5) for _ in cam_addrs]
    pred_queues = [mp.Queue(maxsize=4) for _ in cam_addrs]
    processes = []

    processes.append(mp.Process(target=combine_images, args=(pred_queues, window_name, img_shape)))
    for raw_q, pred_q, cam_addr in zip(raw_queues, pred_queues, cam_addrs):
        processes.append(mp.Process(target=push_image, args=(raw_q, cam_addr)))
        processes.append(mp.Process(target=predict, args=(raw_q, pred_q)))

    [setattr(process, "daemon", True) for process in processes]
    [process.start() for process in processes]
    [process.join() for process in processes]


if __name__ == '__main__':
    mp.set_start_method(method='spawn')

    parser = ArgumentParser()
    parser.add_argument('--num_cameras', '-n', type=int,
                        help='number of cameras to process')
    parser.add_argument('--single_window', '-s', type=str, default='True',
                        help='should multiple cameras displayed in one single window,\
                            only used when number of cameras > 1')
    args = parser.parse_args()

    # 加载设置
    # group_name = "8"
    # cam_addrs = [cam_info['rtsp_url'] for cam_info in camera_data.values() if cam_info['group'] == group_name]
    # cam_addrs = [cam_info['rtsp_url'] for cam_info in camera_data.values()]
    # print(cam_addrs)
    cam_ids = list(range(len(cam_addrs)))

    args.single_window = True if args.single_window.lower() == 'true' else False
    args.num_cameras = len(cam_addrs) if args.num_cameras is None else args.num_cameras

    print(args.num_cameras)

    display(cam_addrs[:args.num_cameras], ['camera' for _ in cam_addrs], img_shape)

