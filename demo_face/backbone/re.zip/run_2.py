# -*- coding:utf-8 -*-
import cv2
import sys
import time
import numpy as np
import multiprocessing as mp
from argparse import ArgumentParser
import logging

from retinaface import Retinaface
from settings import cam_addrs, img_shape

logging.basicConfig(level=logging.INFO)

# 捕获视频流
# def push_image(raw_q, cam_addrs):
#     caps = [cv2.VideoCapture(cam_addr, cv2.CAP_FFMPEG) for cam_addr in cam_addrs]
#     while True:
#         for cap, cam_addr in zip(caps, cam_addrs):
#             is_opened, frame = cap.read()
#             t1 = time.time()
#             if is_opened:
#                 raw_q.put((frame, cam_addr, t1))
#             else:
#                 logging.error(f"Failed to read from camera: {cam_addr}")
#                 cap = cv2.VideoCapture(cam_addr, cv2.CAP_FFMPEG)
#         if raw_q.qsize() > 19:
#             # Remove old image
#             raw_q.get()
#         else:
#             # Wait
#             time.sleep(0.1)
import time


# 捕获视频流
def push_image(raw_q, cam_addr):
    caps = [cv2.VideoCapture(cam_addr, cv2.CAP_FFMPEG) for cam_addr in cam_addrs]
    frame_rate = 5  # 每秒取5帧
    delay = 1.0 / frame_rate

    while True:
        for cap, cam_addr in zip(caps, cam_addrs):
            start_time = time.time()

            is_opened, frame = cap.read()
            t1 = time.time()

            if is_opened:
                raw_q.put((frame, cam_addr, t1))
            else:
                cap = cv2.VideoCapture(cam_addr, cv2.CAP_FFMPEG)

            elapsed_time = time.time() - start_time
            if elapsed_time < delay:
                time.sleep(delay - elapsed_time)


def predict(raw_q, pred_q):
    try:
        retinaface = Retinaface()
        while True:
            raw_img, cam_address, t1 = raw_q.get()

            # Format conversion, BGRtoRGB
            raw_img = cv2.cvtColor(raw_img, cv2.COLOR_BGR2RGB)
            # Perform detection
            pred_img = np.array(retinaface.detect_image(raw_img, 'output/result', t1, cam_address))
            # RGBtoBGR satisfies the display format of opencv
            pred_img = cv2.cvtColor(pred_img, cv2.COLOR_RGB2BGR)
            pred_q.put(pred_img)
            toc = time.time()
            time_cost = toc - t1
            logging.info(f'Processed in {time_cost:.3f}s FPS = {1 / time_cost:.3f}')
    except Exception as e:
        logging.exception("Exception in predict")


def pop_image(pred_q, window_name, img_shape):
    cv2.namedWindow(window_name, flags=cv2.WINDOW_FREERATIO)
    while True:
        frame = pred_q.get()
        frame = cv2.resize(frame, img_shape)
        cv2.imshow(window_name, frame)
        cv2.waitKey(1)


def get_window_name(cam_addr):
    return cam_addr.split('@')[-1]


if __name__ == '__main__':

    img_shape = (1080, 720)

    raw_q = mp.Queue(maxsize=20)
    pred_qs = [mp.Queue(maxsize=10) for _ in cam_addrs]
    processes = []

    processes.append(mp.Process(target=push_image, args=(raw_q, cam_addrs)))
    for pred_q in pred_qs:
        processes.append(mp.Process(target=predict, args=(raw_q, pred_q)))
    for pred_q, cam_addr in zip(pred_qs, cam_addrs):
        window_name = get_window_name(cam_addr)
        processes.append(mp.Process(target=pop_image, args=(pred_q, window_name, img_shape)))

    [process.start() for process in processes]
    [process.join() for process in processes]
